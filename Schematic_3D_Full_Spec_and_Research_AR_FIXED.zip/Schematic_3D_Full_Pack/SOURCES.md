# المصادر والروابط — تحقق 29 أكتوبر 2026

## Litematica
- https://github.com/maruohon/litematica
- https://litematicamod.com/

## Construct
- https://www.curseforge.com/minecraft-bedrock/addons/construct
- https://www.curseforge.com/minecraft-bedrock/addons/construct/files/all
- https://github.com/ForestOfLight/Construct
- https://mcpedl.com/construct/

في تاريخ البحث ظهرت نسخة Construct-v1.2.0 لـ 26.40، ونسخ أحدث لـ 26.50. اختر الملف المطابق للإصدار، لا الأحدث تلقائياً.

## Bedrockmatika
- https://mcpedl.com/bedrockmatika/
- https://www.curseforge.com/minecraft-bedrock/addons/bedrockmatika

الصفحة عرضت 1.2.21-EN.mcaddon ودعم صيغ متعددة عبر ورشة الويب؛ المشروع حديث ويحتاج اختباراً عملياً.

## Minecraft Bedrock
- https://learn.microsoft.com/minecraft/creator/scriptapi
- https://learn.microsoft.com/en-us/minecraft/creator/scriptapi/minecraft/server/structuremanager?view=minecraft-bedrock-stable
- https://learn.microsoft.com/en-us/minecraft/creator/scriptapi/minecraft/server/structure?view=minecraft-bedrock-stable
- https://wiki.bedrock.dev/nbt/mcstructure
- https://learn.microsoft.com/en-us/minecraft/creator/documents/bedrockeditor/editorstructures?view=minecraft-bedrock-stable
- https://minecraft.wiki/w/Bedrock_Edition_26.40

## Flutter
- https://docs.flutter.dev/app-architecture/design-patterns/offline-first

## ملاحظات
هذه الصفحات توثق الميزات أو واجهات API، لكنها ليست ضماناً بأن كل شيء يعمل على كل هاتف. راجع الترخيص قبل إعادة استخدام الكود. اختبر التكامل على Minecraft Android فعلياً.
