# المعمارية والمهارات التقنية المطلوبة

## Flutter
- Dart وnull safety وasync/await وstreams.
- بنية Feature-first أو Clean Architecture مع حدود واضحة.
- فصل Widgets عن domain logic.
- إدارة حالة موثقة مثل Riverpod/Bloc أو بديل مدروس.
- قاعدة بيانات محلية وفهارس بحث وmigrations.
- RTL للعربية وLTR للفرنسية والإنجليزية.
- UI responsive للشاشات الصغيرة وإتاحة الاستخدام.

## Android
- Storage Access Framework وfile picker وcontent URIs.
- Clipboard وShare/Open-with عند الدعم.
- scoped storage وتخزين الملفات داخل مساحة التطبيق.
- عدم طلب صلاحيات شاملة دون سبب.
- عدم افتراض الوصول المباشر إلى مجلد Minecraft الخاص.

## ملفات Minecraft
- JSON Schema validation.
- NBT وpalette وblock states حسب الحاجة.
- `.mcstructure` و`.schem` و`.schematic` مع محولات مستقلة.
- التحقق من IDs والحالات والإحداثيات والحجم.
- الحفاظ على الملف الأصلي عند فشل التحويل.
- منع path traversal عند فك ZIP وعدم تنفيذ أي script من ملف مستورد.

## 3D والأداء
- vertices/indices/normals/UVs/transforms.
- mesh batching أو instancing حيث يتاح.
- chunking وculling وتحميل تدريجي.
- لا تنشئ Widget منفصل لكل بلوك في مبنى ضخم.
- قياس FPS/RAM/وقت التحليل على هاتف فعلي.

## Minecraft Bedrock
- Behavior Pack، Resource Pack، manifest، UUIDs.
- Script API وإصداراتها.
- StructureManager وStructure.
- تنظيم `structures/` داخل الحزمة.
- معرفة القيود بين وضع هيكل جاهز ورسم هولوغرام تفاعلي.
- اختبار Beta APIs المطلوبة على الإصدار المستهدف.
- التحقق من اختلافات Creative وSurvival والسيرفرات.

## هندسة التطبيقات
- Repository pattern، dependency injection، error handling.
- Unit/widget/integration tests.
- logging وdiagnostics.
- schema versioning وmigration.
- معالجة الملفات التالفة والضخمة.
- رسائل خطأ قابلة للترجمة.
- عدم إعلان ميزة مكتملة بلا اختبار.

## بنية مصدر مقترحة
```text
schematic_3d/
  app/lib/core/
  app/lib/domain/
  app/lib/data/
  app/lib/features/library/
  app/lib/features/import_design/
  app/lib/features/viewer_3d/
  app/lib/features/materials/
  app/lib/features/prompt_copy/
  app/test/
  bedrock_addon/behavior_pack/
  bedrock_addon/resource_pack/
  converter/schemas/
  converter/parsers/
  converter/exporters/
  converter/tests/
  docs/
```

## منهج العمل
1. افحص البيئة والمستودع.
2. إثبات جدوى استيراد هيكل واحد في Bedrock 26.40.5.
3. تعريف JSON Schema ومحول أولي.
4. بناء مكتبة Flutter.
5. بناء عارض 3D.
6. تطوير Add-on وتكامل الملفات.
7. إضافة الموارد والبناء التدريجي.
8. الاختبار والأداء والأمان.
9. تسليم APK وMCAddon والمصدر والتوثيق.
