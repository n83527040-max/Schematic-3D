# بحث مقارنة — Litematica وConstruct وBedrockmatika

تاريخ البحث: 29 أكتوبر 2026. الإصدارات قد تتغير؛ راجع صفحات الملفات قبل التنزيل.

## Litematica (Java Edition)
المصدر: https://github.com/maruohon/litematica و https://litematicamod.com/
Litematica مود client-side لمinecraft Java ويتطلب MaLiLib بحسب المستودع. يقدم تحميل المخططات، هولوغراماً، إدارة مواضع المخطط، تدوير/تحريك/مرآة، عرض طبقات، قائمة مواد، فحص أخطاء البناء، وبعض أدوات Easy Place وCreative.
**مهم:** لا يعمل مباشرة كمود Bedrock Android؛ Java/Fabric APIs لا تنتقل حرفياً إلى Bedrock. استخدمه مرجعاً للوظائف لا كوداً جاهزاً.

## Construct — أقرب مرجع لـ Bedrock 26.40
المصادر:
- https://www.curseforge.com/minecraft-bedrock/addons/construct
- https://www.curseforge.com/minecraft-bedrock/addons/construct/files/all
- https://github.com/ForestOfLight/Construct
صفحة الملفات تعرض Construct-v1.2.0.mcaddon لـ 26.40 (حوالي 1.2 MB في الصفحة)، بينما إصدارات أحدث من ذلك تستهدف 26.50. لنسخة Minecraft 26.40.5، لا تختَر أحدث ملف تلقائياً؛ اختر الإصدار المعلن لـ 26.40.
الميزات المنشورة: Structure Hologram، Easy Place، Block Validation، Material Grabbing، Layered Building، إدارة عدة هياكل واستيراد هياكل. تعليمات المشروع تذكر Beta APIs.
أمثلة: عرض قلعة شفافاً، بناء طابق طبقة بطبقة، التحقق من البلوكات الخاطئة، وحساب مواد البناء.
هذا مرجع للاختبار والتعلم وليس جزءاً يجب دمجه تلقائياً في مشروع جديد. راجع MIT license ومتطلبات الإشعار قبل إعادة استخدام أي كود.

## Bedrockmatika
المصدر: https://mcpedl.com/bedrockmatika/ وصفحة CurseForge المرتبطة بها.
الصفحة في وقت البحث ذكرت الإصدار Bedrockmatika-1.2.21-EN.mcaddon (137.76 KB)، وأشارت إلى صيغ `.mcstructure` و`.litematic` و`.schem` و`.nbt` عبر ورشة ويب مرافقة. تتضمن الورشة معاينة 3D والطبقات والمواد وتحرير المخططات؛ ويعرض Add-on المخطط داخل اللعبة مع التحريك والتدوير والطبقات.
المشروع حديث وصاحبه يذكر احتمال وجود أخطاء وحدود توافق، وأن التحويل من Java إلى Bedrock لا يضمن تطابق كل بلوك أو ميكانيكية. اختبره على عالم تجريبي ولا تضمن عمله على كل Realm/هاتف.

## أدوات Bedrock الرسمية/المجتمعية
- Script API: https://learn.microsoft.com/minecraft/creator/scriptapi
- StructureManager: https://learn.microsoft.com/en-us/minecraft/creator/scriptapi/minecraft/server/structuremanager?view=minecraft-bedrock-stable
- Structure: https://learn.microsoft.com/en-us/minecraft/creator/scriptapi/minecraft/server/structure?view=minecraft-bedrock-stable
- `.mcstructure`: https://wiki.bedrock.dev/nbt/mcstructure
- Bedrock Editor Structures: https://learn.microsoft.com/en-us/minecraft/creator/documents/bedrockeditor/editorstructures?view=minecraft-bedrock-stable

StructureManager يضم عمليات مثل getPackStructureIds وgetWorldStructureIds وplace، وStructure تمثل قالب هيكل. لكن ذلك لا يعني أن التطبيق يستطيع حقن أي ملف من Android إلى اللعبة مباشرة أو أن API ترسم هولوغراماً كاملاً تلقائياً. يجب اختبار مسار الاستيراد والواجهة المتاحة في 26.40.5. دليل Bedrock Wiki يوضح أن تصدير mcstructure عبر Structure Block من واجهة اللعبة متاح على Windows فقط، ما يجعل مسار Android نقطة اختبار مهمة.

## المقارنة
| الوظيفة | Litematica | Construct | Bedrockmatika | هدف Schematic 3D |
|---|---|---|---|---|
| المنصة | Java | Bedrock | Bedrock + Web workshop | Android Bedrock |
| هولوغرام | نعم | نعم | نعم وفق وصف المشروع | مطلوب، يحتاج إثبات |
| الطبقات | نعم | نعم | نعم | مطلوب |
| قائمة مواد | نعم | نعم | نعم/عبر الورشة | مطلوب |
| فحص أخطاء | نعم | نعم | ميزات تحقق | مطلوب حسب API |
| صيغ Java | بعض الصيغ | ليس محوره | يذكر دعمها عبر الورشة | عبر محول |
| عمل محلي بالكامل | غالباً | داخل اللعبة مع إعداد | قد يحتاج ورشة للتهيئة | هدف أساسي |

## توصية البحث
1. اختبر Construct v1.2.0 على Minecraft Bedrock 26.40.5.
2. اختبر Bedrockmatika على نسخة عالم منفصلة.
3. وثّق ما يعمل فعلياً على الهاتف.
4. ابنِ Schematic 3D كمنتج أصلي مع تطبيق Flutter ومحول بيانات، ولا تفترض أن أي إضافة جاهزة تحل كل المتطلبات.
